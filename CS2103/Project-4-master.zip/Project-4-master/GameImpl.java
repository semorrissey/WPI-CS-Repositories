import javafx.scene.layout.*;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.animation.AnimationTimer;
import javafx.scene.input.MouseEvent;
import javafx.event.*;
import javafx.geometry.Bounds;
import javafx.scene.media.*;
import javafx.scene.layout.*;
import javafx.scene.control.Label;
import javafx.scene.image.*;

public class GameImpl extends Pane implements Game {
	/**
	 * Defines different states of the game.
	 */
	public enum GameState {
		WON, LOST, ACTIVE, NEW
	}

	// Constants
	/**
	 * The width of the game board.
	 */
	public static final int WIDTH = 400;
	/**
	 * The height of the game board.
	 */
	public static final int HEIGHT = 600;

	// Instance variables
	private Ball ball;
	private Paddle paddle;
	private int lives;
	private boolean hasHitSomethingElse;
	final private Image DUCK = new Image(getClass().getResourceAsStream("duck.jpg"));
	final private Image GOAT = new Image(getClass().getResourceAsStream("goat.jpg"));
	final private Image HORSE = new Image(getClass().getResourceAsStream("horse.jpg"));

	/**
	 * Constructs a new GameImpl.
	 */
	public GameImpl() {
		setStyle("-fx-background-color: white;");
		
		restartGame(GameState.NEW);
	}

	public String getName() {
		return "Zutopia";
	}

	public Pane getPane() {
		return this;
	}

	private void restartGame(GameState state) {
		getChildren().clear(); // remove all components from the game

		// Create and add ball
		ball = new Ball();
		getChildren().add(ball.getCircle()); // Add the ball to the game board

		// Create and add animals
		addAnimals();

		// Create and add paddle
		paddle = new Paddle();
		getChildren().add(paddle.getRectangle()); // Add the paddle to the game board

		// Set lives to 5
		lives = 5;

		//Initializes hasHitSomethingElse variable
		hasHitSomethingElse = false;
		
		// Add start message
		final String message;
		if (state == GameState.LOST) {
			message = "Game Over\n";
		} else if (state == GameState.WON) {
			message = "You won!\n";
		} else {
			message = "";
		}
		final Label startLabel = new Label(message + "Click mouse to start");
		startLabel.setLayoutX(WIDTH / 2 - 50);
		startLabel.setLayoutY(HEIGHT / 2 + 100);
		getChildren().add(startLabel);

		// Add event handler to start the game
		setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				GameImpl.this.setOnMouseClicked(null);

				// As soon as the mouse is clicked, remove the startLabel from
				// the game board
				getChildren().remove(startLabel);
				run();
			}
		});

		// Add event handler to steer paddle
		setOnMouseMoved(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				paddle.moveTo(e.getSceneX(), e.getSceneY());
			}
		});
	}

	/**
	 * Begins the game-play by creating and starting an AnimationTimer.
	 */
	public void run() {
		// Instantiate and start an AnimationTimer to update the component of
		// the game.
		new AnimationTimer() {
			private long lastNanoTime = -1;

			public void handle(long currentNanoTime) {
				if (lastNanoTime >= 0) { // Necessary for first clock-tick.
					GameState state;
					if ((state = runOneTimestep(currentNanoTime - lastNanoTime)) != GameState.ACTIVE) {
						// Once the game is no longer ACTIVE, stop the
						// AnimationTimer.
						stop();
						// Restart the game, with a message that depends on
						// whether
						// the user won or lost the game.
						restartGame(state);
					}
				}
				// Keep track of how much time actually transpired since the
				// last clock-tick.
				lastNanoTime = currentNanoTime;
			}
		}.start();
	}

	/**
	 * Updates the state of the game at each time step. In particular, this
	 * method should move the ball, check if the ball collided with any of the
	 * animals, walls, or the paddle, etc.
	 * 
	 * @param deltaNanoTime
	 *            how much time (in nanoseconds) has transpired since the last
	 *            update
	 * @return the current game state
	 */
	public GameState runOneTimestep(long deltaNanoTime) {
		ball.updatePosition(deltaNanoTime);
		checkCollisions();

		if (lives == 0) {
			return GameState.LOST;
		} else if (getChildren().size() == 2) {
			// Last remaining elements in the pane would be paddle and ball
			return GameState.WON;
		} else {
			return GameState.ACTIVE;
		}
	}

	/**
	 * Check for collisions with any object and react accordingly.
	 * For collisions with the paddle and wall, should only change 
	 * velocity of the ball to be in the opposite direction of collision. 
	 * For collisions with animals should also increase speed.
	 */
	private void checkCollisions() {
		Bounds ballBounds = ball.getCircle().getBoundsInParent();
		if (ballBounds.intersects(paddle.getX() - paddle.PADDLE_WIDTH/2, paddle.getY() - paddle.PADDLE_HEIGHT/2 - 4, paddle.PADDLE_WIDTH, 4)) {
			ball.bounce("-y", false);
			hasHitSomethingElse = true;
		} else if (ballBounds.intersects(paddle.getX() - paddle.PADDLE_WIDTH/2, paddle.getY() + paddle.PADDLE_HEIGHT/2, paddle.PADDLE_WIDTH, 4)) {
			ball.bounce("y", false);
			hasHitSomethingElse = true;
		}
		else if(ballBounds.intersects(-30, 0, 30, HEIGHT)) {
			ball.bounce("x",false);
			hasHitSomethingElse = true;
		}
		else if(ballBounds.intersects(WIDTH, 0, 30, HEIGHT)) {
			ball.bounce("-x", false);
			hasHitSomethingElse = true;
		}
		else if(ballBounds.intersects(0, -30, WIDTH, 30)) {
			ball.bounce("y",false);
			hasHitSomethingElse = true;
		}
		else if(ballBounds.intersects(0, HEIGHT, WIDTH, 30)) {
			//check to see if the ball has hit something else so that it does not subtract multiple lives in one collision
			if(hasHitSomethingElse)
				lives--;
			ball.bounce("-y",false);
			hasHitSomethingElse = false;
		}
		else {
			//Animals are located at indices 1-16, avoid indices 0 and 17 which are the paddle and ball.
			for (int i = 1; i < getChildren().size() - 1; i++) {
				Label n = (Label) getChildren().get(i);
				//5 and 10 values prevent overlap of collision margins
				if (ballBounds.intersects(n.getLayoutX() + n.getWidth() - 5, n.getLayoutY() + 5, 5, n.getHeight() - 10)) {
					ball.bounce("x", true);
					hasHitSomethingElse = true;
					getChildren().remove(n);
				} else if (ballBounds.intersects(n.getLayoutX(), n.getLayoutY() + 5, 5, n.getHeight() - 10)) {
					ball.bounce("-x", true);
					hasHitSomethingElse = true;
					getChildren().remove(n);
				} else if (ballBounds.intersects(n.getLayoutX(), n.getLayoutY() + n.getHeight() - 5, n.getWidth(), 5)) {
					ball.bounce("y", true);
					hasHitSomethingElse = true;
					getChildren().remove(n);
				} else if (ballBounds.intersects(n.getLayoutX(), n.getLayoutY(), n.getWidth(), 5)) {
					ball.bounce("-y", true);
					hasHitSomethingElse = true;
					getChildren().remove(n);
				}
			}
		}
	}
	
	/**
	 * Add all 16 animals to the game board in a 4x4 pattern, 
	 * rotating between Duck, Goat and Horse respectively.
	 */
	private void addAnimals() {
		for (int i = 1; i < 17; i++) {
			Image image = DUCK;
			int x = i % 3;
			int y = i % 4;

			if (x == 0) {
				image = HORSE;
			} else if (x == 1) {
				image = DUCK;
			} else {
				image = GOAT;
			}

			if (y == 0) {
				x = 4;
			} else if (y == 1) {
				x = 1;
			} else if (y == 2) {
				x = 2;
			} else {
				x = 3;
			}

			if (i <= 4) {
				y = 1;
			} else if (i <= 8) {
				y = 2;
			} else if (i <= 12) {
				y = 3;
			} else {
				y = 4;
			}
			Label animal = new Label("", new ImageView(image));
			animal.setLayoutX(WIDTH * x / 5 - image.getWidth() / 2);
			animal.setLayoutY(HEIGHT * y / 10 - image.getHeight() / 2);
			getChildren().add(animal);
		}
	}
}
