public class Image {
	String filename;
	public Image (String filename) {
		this.filename = filename;
	}
}
