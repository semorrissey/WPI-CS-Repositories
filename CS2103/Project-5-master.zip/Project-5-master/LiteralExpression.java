import java.util.List;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class LiteralExpression implements Expression {
	private String _str;
	private CompoundExpression _parent;
	private Label _label;

	/**
	 * Constructs a LiteralExpression object with the given string
	 * @param str The String representing the value of the Literal
	 */
	public LiteralExpression(String str) {
		_str = str;
	}

	/**
	 * Returns the parent of the Expression.
	 * @return _parent the current parent of the expression
	 */
	public CompoundExpression getParent() {
		return _parent;
	}

	/**
	 * Sets the parent for this expression
	 * @param parent The parent CompoundExpression to be set as the parent of this expression
	 */
	public void setParent(CompoundExpression parent) {
		_parent = parent;
	}

	/**
	 * Creates and returns a fully deep copy of the current Expression completely independent of
	 * this one.
	 * @return Expression 
	 */
	public Expression deepCopy() {
		Expression expr = new LiteralExpression(new String(_str));
		expr.setParent(getParent());
		expr.createNode();
		return expr;
	}

	/**
	 * Purposefully do nothing, LiteralExpression has no children and therefore cannot flatten
	 */
	public void flatten() {}

	/**
	 * @param stringBuilder the stringBuilder to add the expression to
	 * @param indentLevel the number of indents to add infront of the string value
	 * Converts the current expression into a string based on the current expression and indentlevel
	 */
	public void convertToString(StringBuilder stringBuilder, int indentLevel) {
		Expression.indent(stringBuilder, indentLevel);
		stringBuilder.append(_str);
		stringBuilder.append("\n");
	}

	/**
	 * Returns the node associated with this expression.
	 * @return _label The node associated with this expression.
	 */
	public Node getNode() {
		return _label;
	}
	
	/**
	 * Creates a new node for this expression when one does not exist.
	 */
	public void createNode() {
		_label = new Label(_str);
		_label.setFont(LARGE_FONT);
	}
	
	/**
	 * Sees if the x an y coordinates provided are within the bounds of the node relative to the parent.
	 * @param node The node to check the boundaries of
	 * @param x The x-coordinate
	 * @param y The y-coordinate
	 * @return True or False
	 */
	public static boolean contains(Node node, double x, double y) {
		return node.getBoundsInParent().contains(x, y);
	}
	
	/**
	 * Checks to see if the x and y coordinates are contained in this expression and returns this if it 
	 * does or null if it does not.
	 * @param x The x coordinate
	 * @param y The y coordinate
	 * @return this or null
	 */
	public Expression findMostSpecificFocus(double x, double y) {
		if (contains(_label, x, y)) {
			return this;
		}
		return null;
	}
	
	/**
	 * Sets the border of this expression node to a red border from Expression.RED_BORDER.
	 */
	public void addBorder() {
		_label.setBorder(RED_BORDER);
	}
	
	/**
	 * Removes the border of this expression node.
	 */
	public void removeBorder() {
		_label.setBorder(NO_BORDER);
	}
	
	/**
	 * Changes this expression node's text to grey.
	 */
	public void setGrey() {
		setColor(GHOST_COLOR);
	}
	
	/**
	 * Changes this expression node's text to black.
	 */
	public void setBlack() {
		setColor(Color.BLACK);
	}
	/**
	 * Helper function to change the color of this expression's text ot the input color.
	 * @param color
	 */
	public void setColor(Color color) {
		_label.setTextFill(color);
	}
	
	/**
	 * Returns null as LiteralExpressions cannot have children.
	 */
	public List<Expression> getChildren() {
		return null;
	}
}
