import java.util.LinkedList;
import java.util.List;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;

public abstract class ParentExpression extends LiteralExpression implements CompoundExpression {
	protected List<Expression> _children;
	protected HBox _hbox;

	public ParentExpression(String str) {
		super(str);
		_children = new LinkedList<Expression>();
	}

	/**
	 * Adds the input subexpression as a child of this ParentExpression
	 * @param subexpression the expression to become a child of this expression
	 */
	public void addSubexpression(Expression subexpression) {
		_children.add(subexpression);
	}
	
	@Override
	/**
	 * Returns a fully deep copy of this CompoundExpression with fully deep copys of its children
	 * @return Expression
	 */
	public Expression deepCopy() {
		CompoundExpression compoundExpr;
		if (this instanceof ParentheticalExpression) {
			compoundExpr = new ParentheticalExpression();
		} else if (this instanceof AdditiveExpression) {
			compoundExpr = new AdditiveExpression();
		} else {
			compoundExpr = new MultiplicativeExpression();
		}
		compoundExpr.setParent(getParent());
		for (Expression expr : _children) {
			compoundExpr.addSubexpression(expr.deepCopy());
		}
		compoundExpr.createNode();
		return compoundExpr;
	}
	
	@Override
	/**
	 * Flattens from the bottom up. When an expression has a child of the same condition represented by a class,
	 * add all the children of the child into the parent and remove the child from the parents children.
	 * Effectively reduces the height of the expression tree by increasing width. Will flatten nested parenthesis
	 * eg. "((E))"
	 */
	public void flatten() {
		for (int i = 0; i < _children.size(); i++) {
			_children.get(i).flatten();
			while (_children.get(i).getClass().equals(this.getClass())) {
				ParentExpression expr = (ParentExpression) _children.get(i);
				//go backwards to preserve order
				for (int j = expr._children.size() - 1; j > -1; j--) {
					setParentChild(i, expr._children.get(j));
				}
				_children.remove(expr);
			}
		}
	}

	@Override
	/**
	 * Converts to a string format the current CompoundExpression along with its children based indent level
	 * @param stringBuilder the StringBuilder with which to build the string format of the expression on
	 * @param indentLevel the number of indents to add to the stringBuilder
	 */
	public void convertToString(StringBuilder stringBuilder, int indentLevel) {
		super.convertToString(stringBuilder, indentLevel);
		for (Expression expr : _children) {
			expr.convertToString(stringBuilder, indentLevel + 1);
		}
	}
	
	/**
	 * Helper function to set the parent and add children based on the given index and child expression
	 * @param index The index at which to add the child
	 * @param child The child 
	 */
	public void setParentChild(int index, Expression child) {
		_children.add(index, child);
		child.setParent(this);
	}
	
	@Override
	/**
	 * Recursively finds and returns the most specific expression based on where the mouse was clicked, or null if 
	 * no expression was found.
	 */
	public Expression findMostSpecificFocus(double x, double y) {
		if (contains(_hbox, x, y)) {
			for (Expression expr : _children) {
				Expression expression;
				if ((expression = expr.findMostSpecificFocus(x - getNode().getLayoutX(), y - getNode().getLayoutY())) != null) {
					return expression;
				}
			}
			return this;
		}
		return null;
	}
	
	@Override
	/**
	 * Returns the node associated with this expression.
	 */
	public Node getNode() {
		return _hbox;
	}
	
	@Override
	/**
	 * Creates a new node when called.
	 */
	public void createNode() {
		_hbox = createHBox();
	}
	
	/**
	 * Creates an HBox object and fills its children based on the current expression tree.
	 */
	public abstract HBox createHBox();
	
	@Override
	/**
	 * Adds a red border around this expression.
	 */
	public void addBorder() {
		_hbox.setBorder(RED_BORDER);
	}
	
	@Override
	/**
	 * removes a border around this expresson by setting it to blank.
	 */
	public void removeBorder() {
		_hbox.setBorder(NO_BORDER);
	}
	
	@Override
	/**
	 * Recusively sets the label objects in the node's children to grey.
	 */
	public void setGrey() {
		setColor(GHOST_COLOR);
	}
	
	@Override
	/**
	 * Recursively sets the label objects in the node's children to black.
	 */
	public void setBlack() {
		setColor(Color.BLACK);
	}
	
	@Override
	/**
	 * Changes the color of all label objects in a node and recursively sets he color to the input
	 * color on all other children of the expression.
	 * @param color The color to change the labels and expressions to.
	 */
	public void setColor(Color color) {
		for (Node node : _hbox.getChildren()) {
			if (node instanceof Label) {
				((Label) node).setTextFill(color);
			}
		}
		for (Expression expr : _children) {
			expr.setColor(color);
		}
	}
	
	@Override 
	/** 
	 * Returns this expression's list of children.
	 * @return _children
	 */ 
	public List<Expression> getChildren() { 
		return _children; 
	} 
	
	/**
	 * Swap the nodes of an expressions children with the given list of expressions.
	 */
	public abstract void swapNodes(List<Expression> list);
}
