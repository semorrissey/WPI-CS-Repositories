import java.util.List;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;

public class SimpleCompoundExpression extends ParentExpression {
	public SimpleCompoundExpression(String str) {
		super(str);
	}
	
	@Override
	/**
	 * Creates a new node in the case that one does not exist yet and creates nodes of all children.
	 */
	public HBox createHBox() {
		HBox hbox = new HBox();
		Label label;
		for (int i = 0; i < _children.size(); i++) {
			_children.get(i).createNode();
			hbox.getChildren().add(_children.get(i).getNode());
			if (this instanceof AdditiveExpression) {
				label = new Label("+");
				label.setFont(LARGE_FONT);
				hbox.getChildren().add(label);
			} else {
				label = new Label("*");
				label.setFont(LARGE_FONT);
				hbox.getChildren().add(label);
			}
		}
		if (hbox.getChildren().size() > 1) {
			hbox.getChildren().remove(hbox.getChildren().size() - 1);
		}
		return hbox;
	}
	
	/**
	 * Clears and replaces this expression's node children with the nodes of the given list of expressions.
	 */
	public void swapNodes(List<Expression> list) {
		_hbox.getChildren().clear();
		Label label;
		for (Expression expr : list) {
			_hbox.getChildren().add(expr.getNode());
			if (this instanceof AdditiveExpression) {
				label = new Label("+");
				label.setFont(LARGE_FONT);
				_hbox.getChildren().add(label);
			} else {
				label = new Label("*");
				label.setFont(LARGE_FONT);
				_hbox.getChildren().add(label);
			}
		}
		if (_hbox.getChildren().size() > 1) {
			_hbox.getChildren().remove(_hbox.getChildren().size() - 1);
		}
	}
}
