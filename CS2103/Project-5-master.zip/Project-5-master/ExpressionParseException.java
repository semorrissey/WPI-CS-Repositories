class ExpressionParseException extends Exception {
	public ExpressionParseException (String message) {
		super(message);
	}
}
