import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

/**
 * Starter code to implement an ExpressionParser. Your parser methods should use the following grammar:
 * E := A | X
 * A := A+M | M
 * M := M*M | X
 * X := (E) | L
 * L := [0-9]+ | [a-z]
 */
public class SimpleExpressionParser implements ExpressionParser {
	/*
	 * Attempts to create an expression tree -- flattened as much as possible -- from the specified String.
	 * Throws a ExpressionParseException if the specified string cannot be parsed.
	 * @param str the string to parse into an expression tree
	 * @param withJavaFXControls you can just ignore this variable for R1
	 * @return the Expression object representing the parsed expression tree
	 */
	public Expression parse (String str, boolean withJavaFXControls) throws ExpressionParseException {
		// Remove spaces -- this simplifies the parsing logic
		str = str.replaceAll(" ", "");
		Expression expression = parseExpression(str);
		if (expression == null) {
			// If we couldn't parse the string, then raise an error
			throw new ExpressionParseException("Cannot parse expression: " + str);
		}

		// Flatten the expression before returning
		expression.flatten();
		
		// Create the nodes of each subexpression
		expression.createNode();
		return expression;
	}

	/**
	 * Represents the E condition of the CFG, checks for A and X possibilities
	 * @param str The string to parse into an expression tree
	 * @return A complete expression or null if str could not be parsed
	 */
	protected Expression parseExpression (String str) {
		//Check for A
		Expression expression = parseA(str);
		if (expression != null) {
			return expression;
		} 
		//Check for X
		return parseX(str);
	}

	/**
	 * Represents the A condition of the CFG, uses parseHelper to check for A+M and M possibilites
	 * @param str The String to parse into an expression tree
	 * @return A complete expression of condition A or null if str could not be parsed
	 */
	private Expression parseA(String str) {
		return parseHelper(str, '+', 
				String -> parseA(String), 
				String -> parseM(String), 
				String -> parseM(String));
	}

	/**
	 * Represents the M condition of the CFG, uses parseHelper to check for M*M and X possibilites
	 * @param str The String to parse into an expression tree
	 * @return A complete expression of condition M or null if str could not be parsed
	 */
	private Expression parseM(String str) {
		return parseHelper(str, '*', 
				String -> parseM(String), 
				String -> parseM(String), 
				String -> parseX(String));
	}

	/**
	 * Represents the X condition of the CFG, checks for (E) and L possibilities
	 * and creates the new expressions
	 * @param str The String to parse into an expression tree
	 * @return A complete expression of condition X or null if str could not be parsed
	 */
	private Expression parseX(String str) {
		//Check for (E)
		ParentExpression parentExpr;
		Expression expr;
		if (str.length() >= 2 && str.charAt(0) == '(' && str.charAt(str.length() - 1) == ')' 
				&& (expr = parseExpression(str.substring(1, str.length() - 1))) != null) {
			parentExpr = new ParentheticalExpression();
			parentExpr.setParentChild(0, expr);
			return parentExpr;
		}
		//Check for L
		if (str.matches("[0-9]+")) {
			expr = new LiteralExpression(str);
			return expr;
		} else if (str.length() == 1 && str.matches("[a-zA-Z]")) {
			expr = new LiteralExpression(str);
			return expr;
		}
		return null;
	}

	/**
	 * Helper function to check conditions in the CFG where an operation is looked for to parse around
	 * @param str The String to parse into an expression
	 * @param operation the operation to check for in parsing
	 * @param m1 The first method to check the left side of the operation
	 * @param m2 The second method to check the right side of the operation
	 * @param m3 The third method to check the second condition should the first condition not be met
	 * @return A complete expression or null if could not be parsed
	 */
	private Expression parseHelper(String str, char operation,
			Function<String, Expression> m1, 
			Function<String, Expression> m2,
			Function<String, Expression> m3) {
		//Check condition 1
		ParentExpression compoundExpr;
		for (int i = 0; i < str.length(); i++) {
			Expression leftExpr;
			Expression rightExpr;
			if (str.charAt(i) == operation &&
					//Check left side of operation for valid expression
					(leftExpr = m1.apply(str.substring(0, i))) != null &&
					//Check right side of operation for valid expression
					(rightExpr = m2.apply(str.substring(i + 1))) != null) {
				//Create a new SimpleCompound expression of the operation and add the left
				//and right side as children of this expression, then add compound expression 
				//as parents of the children
				if (operation == '+') {
					compoundExpr = new AdditiveExpression();
				} else {
					compoundExpr = new MultiplicativeExpression();
				}
				compoundExpr.setParentChild(0, leftExpr);
				compoundExpr.setParentChild(1, rightExpr);
				return compoundExpr;
			}
		}
		//Check condition 2 if condition 1 could not be met
		return m3.apply(str);
	}
}
