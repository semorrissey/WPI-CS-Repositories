public class MultiplicativeExpression extends SimpleCompoundExpression {
	public MultiplicativeExpression() {
		super(new String("*"));
	}
}
