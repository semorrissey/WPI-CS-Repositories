import javafx.application.Application;
import java.util.*;
import javafx.geometry.Point2D;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class ExpressionEditor extends Application {
	public static void main (String[] args) {
		launch(args);
	}

	/**
	 * Mouse event handler for the entire pane that constitutes the ExpressionEditor
	 */
	private static class MouseEventHandler implements EventHandler<MouseEvent> {
		Pane _pane;
		CompoundExpression _rootExpression;
		Expression _focusedExpr;
		Expression _deepCopy;
		Point2D _point;
		boolean wasDragged;

		MouseEventHandler (Pane pane_, CompoundExpression rootExpression_) {
			_pane = pane_;
			_rootExpression = rootExpression_;
		}

		public void handle (MouseEvent event) {
			if (event.getEventType() == MouseEvent.MOUSE_PRESSED) {
				// Reset wasDragged
				wasDragged = false;
				if (_focusedExpr != null) {
					// Check where was clicked
					Expression expr = _rootExpression.findMostSpecificFocus(event.getX(), event.getY());
					if (expr == null) {
						// If click is outside of _rootExpression remove focus
						removeFocus();
					}  else if (_deepCopy == null) {
						// If something is currently focused, create a deep copy
						_deepCopy = _focusedExpr.deepCopy();
						_pane.getChildren().add(_deepCopy.getNode());
						_deepCopy.getNode().setLayoutX(_focusedExpr.getNode().localToScene(0, 0).getX());
						_deepCopy.getNode().setLayoutY(_rootExpression.getNode().getLayoutY());
					}
				}
			} else if (event.getEventType() == MouseEvent.MOUSE_DRAGGED) {
				// Mouse has been dragged
				wasDragged = true;
				if (_focusedExpr != null) {	
					// Calculate all possible combinations
					ArrayList<List<Expression>> possibleChildren = calculatePossibleOrientations();
					CompoundExpression parent = _focusedExpr.getParent();
					// Find the distance between the node and the first combination
					double difference = Math.abs(parent.getChildren().get(0).getNode().localToScene(0, 0).getX() - _deepCopy.getNode().localToScene(0,0).getX());
					int possibleIndex = 0;
					// Check against other combinations and find the index of the combination with the smallest distance
					for (int i = 1; i < parent.getChildren().size(); i++){
						if (Math.abs(parent.getChildren().get(i).getNode().localToScene(0, 0).getX() - _deepCopy.getNode().localToScene(0,0).getX()) < difference) {
							difference = Math.abs(parent.getChildren().get(i).getNode().localToScene(0, 0).getX() - _deepCopy.getNode().localToScene(0,0).getX());
							possibleIndex = i;
						}
					}
					// Replace the current Expression tree and nodes with the new combination
					parent.getChildren().clear();
					parent.getChildren().addAll(possibleChildren.get(possibleIndex));
					parent.swapNodes(possibleChildren.get(possibleIndex));
					// Find the initial point of click
					if (_point == null) {
						_point = new Point2D(event.getSceneX(), event.getSceneY());
					}
					_focusedExpr.setGrey();
					//System.out.println("Layout of X: " + _deepCopy.getNode().getLayoutX());
					//System.out.println("XFinal - XInitial: " + (event.getSceneX() - _point.getX()));
					// Move the Focused Expression based on where the mouse is and where the initial click was
					_deepCopy.getNode().setTranslateX(event.getSceneX() - _point.getX());
					_deepCopy.getNode().setTranslateY(event.getSceneY() - _point.getY());
					//System.out.println("Translate: " + _focusedExpr.getNode().getTranslateX());
				}
			} else if (event.getEventType() == MouseEvent.MOUSE_RELEASED) {
				if (wasDragged) {
					if (_focusedExpr != null) {
						// Show new expression
						_focusedExpr.setBlack();
						_point = null;
						System.out.println(_rootExpression.convertToString(0).toString());
					}
				} else {
					// Find specific focus of click
					Expression expr = _rootExpression.findMostSpecificFocus(event.getX(), event.getY());
					/* If no expression is focused right now, and the find specific focus returns an expression,
					   set the largest expression of the root where the click was to be the focus. */
					if (expr != null && _focusedExpr == null) {
						for (Expression childExpr : _rootExpression.getChildren()) {
							if (childExpr.findMostSpecificFocus(event.getX() - _rootExpression.getNode().getLayoutX(), event.getY() - _rootExpression.getNode().getLayoutY()) != null) {
								_focusedExpr = childExpr;
								_focusedExpr.addBorder();
								break;
							}
						}
					} else if (expr != null && _focusedExpr !=null) {
						// If something is already focused, then continue to cycle through its children.
						if (_focusedExpr.getChildren() != null) {
							boolean didNotFindSpecific = true;
							Point2D point = _focusedExpr.getNode().localToScene(0, 0);
							for (Expression childExpr : _focusedExpr.getChildren()) {
								// If a more specific expression is found in one of the children, that child becomes the focus
								if (childExpr.findMostSpecificFocus(event.getSceneX() - point.getX(), event.getSceneY() - point.getY()) != null) {
									// Swap focus
									_focusedExpr.removeBorder();
									_focusedExpr = childExpr;
									_focusedExpr.addBorder();
									didNotFindSpecific = false;
									break;
								}
							}
							// If nothin was found to be more specific then remove focus
							if (didNotFindSpecific) {
								removeFocus();
							}
						} else {
							// If no children then remove focus as it cannot go any deeper
							removeFocus();
						}
					}
				}
				// Remove the deep copy from the pane
				if (_deepCopy != null) {
					_pane.getChildren().remove(_deepCopy.getNode());
					_deepCopy = null;
				}
			}
		}
		
		/**
		 * Calculates all possible orientations for a node in its parent's children
		 * @return an ArrayList of Lists containing the possible orders.
		 */
		private ArrayList<List<Expression>> calculatePossibleOrientations(){
			ArrayList<List<Expression>> result =  new ArrayList<List<Expression>>();
			List<Expression> mainChildren = _focusedExpr.getParent().getChildren();
			for (int i = 0; i < mainChildren.size(); i++) {
				List<Expression> temp = new ArrayList<Expression>();
				temp.addAll(mainChildren);
				temp.remove(_focusedExpr);
				temp.add(i, _focusedExpr);
				result.add(temp);
			}
			return result;
		}
		
		/**
		 * Removes the current focus
		 */
		private void removeFocus() {
			_focusedExpr.removeBorder();
			_focusedExpr = null;
		}
	}

	/**
	 * Size of the GUI
	 */
	private static final int WINDOW_WIDTH = 500, WINDOW_HEIGHT = 250;

	/**
	 * Initial expression shown in the textbox
	 */
	private static final String EXAMPLE_EXPRESSION = "2*x+3*y+4*z+(7+6*z)";

	/**
	 * Parser used for parsing expressions.
	 */
	private final ExpressionParser expressionParser = new SimpleExpressionParser();

	@Override
	public void start (Stage primaryStage) {
		primaryStage.setTitle("Expression Editor");

		// Add the textbox and Parser button
		final Pane queryPane = new HBox();
		final TextField textField = new TextField(EXAMPLE_EXPRESSION);
		final Button button = new Button("Parse");
		queryPane.getChildren().add(textField);

		final Pane expressionPane = new Pane();

		// Add the callback to handle when the Parse button is pressed	
		button.setOnMouseClicked(new EventHandler<MouseEvent>() {
			public void handle (MouseEvent e) {
				// Try to parse the expression
				try {
					// Success! Add the expression's Node to the expressionPane
					final Expression expression = expressionParser.parse(textField.getText(), true);
					System.out.println(expression.convertToString(0));
					expressionPane.getChildren().clear();
					expressionPane.getChildren().add(expression.getNode());
					expression.getNode().setLayoutX(WINDOW_WIDTH/6);
					expression.getNode().setLayoutY(WINDOW_HEIGHT/3);

					// If the parsed expression is a CompoundExpression, then register some callbacks
					if (expression instanceof CompoundExpression) {
						((Pane) expression.getNode()).setBorder(Expression.NO_BORDER);
						final MouseEventHandler eventHandler = new MouseEventHandler(expressionPane, (CompoundExpression) expression);
						expressionPane.setOnMousePressed(eventHandler);
						expressionPane.setOnMouseDragged(eventHandler);
						expressionPane.setOnMouseReleased(eventHandler);
					}
				} catch (ExpressionParseException epe) {
					// If we can't parse the expression, then mark it in red
					textField.setStyle("-fx-text-fill: red");
				}
			}
		});
		queryPane.getChildren().add(button);

		// Reset the color to black whenever the user presses a key
		textField.setOnKeyPressed(e -> textField.setStyle("-fx-text-fill: black"));

		final BorderPane root = new BorderPane();
		root.setTop(queryPane);
		root.setCenter(expressionPane);

		primaryStage.setScene(new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT));
		primaryStage.show();
	}
}