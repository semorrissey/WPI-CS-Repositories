public class AdditiveExpression extends SimpleCompoundExpression {
	public AdditiveExpression() {
		super(new String("+"));
	}
}
