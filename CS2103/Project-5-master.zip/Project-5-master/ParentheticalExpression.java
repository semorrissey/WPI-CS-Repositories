import java.util.List;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;

public class ParentheticalExpression extends ParentExpression {
	public ParentheticalExpression() {
		super(new String("()"));
	}
	
	@Override
	/**
	 * Creates a new Node in the instance that one does not exist yet, and creates nodes of the children.
	 */
	public HBox createHBox() {
		HBox hbox = new HBox();
		Label label1 = new Label("(");
		Label label2 = new Label(")");
		label1.setFont(LARGE_FONT);
		label2.setFont(LARGE_FONT);
		hbox.getChildren().add(label1);
		for (Expression expr : _children) {
			expr.createNode();
			hbox.getChildren().add(expr.getNode());
		}
		hbox.getChildren().add(label2);
		return hbox;
	}
	
	/**
	 * Clears and replaces this expression's node children with the nodes of the given list of expressions.
	 */
	public void swapNodes(List<Expression> list) {
		_hbox.getChildren().clear();
		Label label1 = new Label("(");
		Label label2 = new Label(")");
		label1.setFont(LARGE_FONT);
		label2.setFont(LARGE_FONT);
		_hbox.getChildren().add(label1);
		for (Expression expr : list) {
			_hbox.getChildren().add(expr.getNode());
		}
		_hbox.getChildren().add(label2);
	}
}
