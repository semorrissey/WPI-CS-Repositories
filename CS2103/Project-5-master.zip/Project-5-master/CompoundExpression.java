import java.util.List;

interface CompoundExpression extends Expression {
	/**
	 * Adds the specified expression as a child.
	 * @param subexpression the child expression to add
	 */
	void addSubexpression (Expression subexpression);
	
	/**
	 * Swaps the current nodes of a compound expression with the given list of expressions.
	 * Does not modify the expression children, only the node's children.
	 * @param list The list containing the new expressions
	 */
	void swapNodes(List<Expression> list);
}
